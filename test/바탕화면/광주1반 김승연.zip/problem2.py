for case in range(1, int(input())+1):
    n, m, k = map(int, input().split())
    gets = []
    for i in range(n):
        gets.append(list(map(int, input().split())))
    best = 0
    for i in range(n-k+1):
        for j in range(m-k+1):
            hap = 0
            for out in range(k**2):
                if out//k == 0 or out//k == k-1 or out%k == 0 or out%k == k-1:
                    hap += gets[i + out//k][j + out%k]
            if hap > best:
                best = hap
    print("#{} {}".format(case, best))

