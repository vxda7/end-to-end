for case in range(1, int(input())+1):
    n, m = map(int, input().split())
    space = [[0]*n for i in range(n)]
    for k in range(m):
        x1, y1, x2, y2 = map(int, input().split())
        for i in range(x1, x2+1):
            for j in range(y1, y2+1):
                space[i-1][j-1] = 1     # idx가 0부터 있으므로
    hap = 0
    for i in space:
        hap += sum(i)

    print("#{} {}".format(case, hap))