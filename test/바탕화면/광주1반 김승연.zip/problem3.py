def noisland(i, j, n):  # 섬없애기
    global worldmap
    stack = []
    stack.append([i, j])

    while len(stack) > 0:
        x, y = stack.pop()
        x -= 1      # 테두리 조건이 왼쪽위 칸이므로 중앙의 왼쪽 위로 점을 옮긴다.
        y -= 1
        for out in range(9):
            if out // 3 == 0 or out // 3 == 2 or out % 3 == 0 or out % 3 == 2:
                if 0 <= x + out // 3 < n and 0 <= y + out % 3 < n:  # 값이 지도안에 있는가?
                    if worldmap[x + out // 3][y + out % 3] > 0:     # 물이 아닌 땅인가?
                        stack.append([x + out // 3, y + out % 3])   # 좌표 추가
                        worldmap[x + out // 3][y + out % 3] = 0     # 근처의 땅 제거
    return 1


for case in range(1, int(input()) + 1):
    n = int(input())
    worldmap = [list(map(int, input().split())) for i in range(n)]
    empty = [[0]*n for i in range(n)]
    island = 0
    for i in range(n):
        for j in range(n):
            if worldmap[i][j]:  # 값이 존재하면
                island += noisland(i, j, n) # 값이 있으면 섬추가 후 섬없애기
                worldmap[i][j] = 0  # 처음 땅이 모서리일 경우 안지워지므로 삭제

    print("#{} {}".format(case, island))



